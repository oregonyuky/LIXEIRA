// _______________________________________________ //
// ********** Módulos Internos/Externos ********** //

const express = require('express');
const cors = require('cors');
const chalk = require('chalk');
const ConsultaRoutes = require('./routes/ConsultaRoutes');
const PacienteRoutes = require('./routes/PacienteRoutes');

const app = express();                 // ? kkg6gy6
const port = 5000;                     
const host = 'localhost';              

app.use(cors());                       
app.use(express.json());               
app.use('/consulta', ConsultaRoutes);  
app.use('/paciente', PacienteRoutes);  


app.listen(port, async () =>
{
   console.clear();

   console.log(chalk.cyanBright.bold('\n---------------------------------------------'));
   console.log(chalk.greenBright.bold('       Servidor rodando com sucesso!       '));
   console.log(chalk.cyanBright.bold('---------------------------------------------'));
   console.log(chalk.magenta('Server Host: ') + chalk.magenta(`http://${host}:${port}`));
   console.log(chalk.blueBright.bold('Banco: ') + chalk.blueBright('mongodb://127.0.0.1:27017/centromedico'));
   console.log(chalk.cyanBright.bold('---------------------------------------------\n'));
});