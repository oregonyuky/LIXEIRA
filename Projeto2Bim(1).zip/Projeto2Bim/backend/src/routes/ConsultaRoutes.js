// ____________________________________________ //
// ************** rotas: Consulta ************** //

const express = require('express');
const rotas = express.Router();

const ConsultaController = require('../controllers/ConsultaController');
const ConsultaValidate = require('../middlewares/ConsultaValidate');


// ? ----- Criar Consulta ----- ? //
rotas.post('/', ConsultaValidate, ConsultaController.criar);

// ? ----- Atualizar Contulta ----- ? //
rotas.put('/:id', ConsultaValidate, ConsultaController.atualizar);
rotas.put('/concluida/:id/:termino', ConsultaController.concluida);

// ? ----- Rotas Específicas (antes das genéricas) ----- ? //
rotas.get('/atrasadas', ConsultaController.atrasadas);
rotas.get('/hoje', ConsultaController.consultaHoje);
rotas.get('/semana', ConsultaController.consultaSemana);
rotas.get('/mes', ConsultaController.consultaMes);
rotas.get('/ano', ConsultaController.consultaAno);


// ? ----- Rotas Genéricas (c/s ID) POR ÚLTIMO ----- ? //
rotas.get('/', ConsultaController.listar);
rotas.get('/:id', ConsultaController.buscar);

rotas.delete('/:id', ConsultaController.deletar);

module.exports = rotas;