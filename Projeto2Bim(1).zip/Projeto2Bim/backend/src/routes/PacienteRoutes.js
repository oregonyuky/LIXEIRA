// ____________________________________________ //
// ************** Rotas: Paciente ************** //

const express = require('express');
const rotas = express.Router();

const PacienteController = require('../controllers/PacienteController');
const PacienteValidate = require('../middlewares/PacienteValidate');

// ? ----- Criar Consulta ----- ? //
rotas.post('/', PacienteValidate, PacienteController.criar);

// ? ----- Atualizar Paciente ----- ? //
rotas.put('/:id', PacienteValidate, PacienteController.atualizar);

// ? ----- Consultar o(s) Paciente(s) ----- ? //
rotas.get('/', PacienteController.listar);
rotas.get('/:id', PacienteController.buscar);

// ? ----- Exclusão do Paciente ----- ? //
rotas.delete('/:id', PacienteController.deletar);

module.exports = rotas;