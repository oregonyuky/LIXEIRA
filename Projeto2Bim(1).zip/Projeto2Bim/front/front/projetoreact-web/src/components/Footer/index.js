//importar o react que traz todos os recursos dele
import React from 'react';
import * as Styl from './styles'

function Footer() {
  return (
    <Styl.Container>
        <span>Consult@ - 2025</span>
    </Styl.Container>
  );
}
export default Footer;
